import './globals.css';

export const metadata = {
  title: 'VolatilityForge | Private LONG & SHORT Crypto Signals',
  description:
    'VolatilityForge is a private Discord signal room for selective LONG and SHORT crypto signals, model performance and risk-first execution.',
  icons: {
    icon: '/favicon.svg'
  }
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
