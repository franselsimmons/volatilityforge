import { NextResponse } from 'next/server';

function safeLocale(locale) {
  return ['en', 'nl', 'de', 'es', 'fr'].includes(locale) ? locale : 'nl';
}

export async function POST(request) {
  const formData = await request.formData();
  const locale = safeLocale(String(formData.get('locale') || 'nl'));
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000';

  const payload = {
    name: String(formData.get('name') || ''),
    email: String(formData.get('email') || ''),
    experience: String(formData.get('experience') || ''),
    plan: String(formData.get('plan') || ''),
    notes: String(formData.get('notes') || ''),
    locale,
    source: 'volatilityforge-access-application',
    createdAt: new Date().toISOString()
  };

  const webhookUrl = process.env.APPLICATION_WEBHOOK_URL;

  if (webhookUrl) {
    await fetch(webhookUrl, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(payload)
    });
  }

  return NextResponse.redirect(new URL(`/${locale}/success?application=received`, siteUrl), 303);
}
