import Stripe from 'stripe';
import { NextResponse } from 'next/server';

const priceEnvByPlan = {
  monthly: 'STRIPE_PRICE_MONTHLY',
  sixMonths: 'STRIPE_PRICE_SIX_MONTHS',
  annual: 'STRIPE_PRICE_ANNUAL'
};

function safeLocale(locale) {
  return ['en', 'nl', 'de', 'es', 'fr'].includes(locale) ? locale : 'nl';
}

export async function POST(request) {
  const formData = await request.formData();
  const plan = String(formData.get('plan') || 'sixMonths');
  const locale = safeLocale(String(formData.get('locale') || 'nl'));

  const paymentsEnabled = process.env.NEXT_PUBLIC_ENABLE_PAYMENTS === 'true';
  const stripeSecret = process.env.STRIPE_SECRET_KEY;
  const priceEnv = priceEnvByPlan[plan];
  const priceId = priceEnv ? process.env[priceEnv] : '';
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000';

  if (!paymentsEnabled || !stripeSecret || !priceId) {
    return NextResponse.redirect(new URL(`/${locale}/apply?plan=${plan}&payment=not-configured`, siteUrl), 303);
  }

  const stripe = new Stripe(stripeSecret);
  const session = await stripe.checkout.sessions.create({
    mode: 'subscription',
    line_items: [
      {
        price: priceId,
        quantity: 1
      }
    ],
    success_url: `${siteUrl}/${locale}/success?checkout=success&session_id={CHECKOUT_SESSION_ID}`,
    cancel_url: `${siteUrl}/${locale}/pricing?checkout=cancelled`,
    allow_promotion_codes: true,
    metadata: {
      product: 'volatilityforge-private-signal-room',
      plan
    }
  });

  return NextResponse.redirect(session.url, 303);
}
