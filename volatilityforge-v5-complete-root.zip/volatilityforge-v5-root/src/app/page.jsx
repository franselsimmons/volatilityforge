import { redirect } from 'next/navigation';
import { defaultLocale } from '@/lib/siteContent';

export default function RootPage() {
  redirect(`/${defaultLocale}`);
}
