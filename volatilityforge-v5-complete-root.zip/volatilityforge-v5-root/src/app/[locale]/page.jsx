import Link from 'next/link';
import SiteShell, { InfoCards, PageHero, StatGrid } from '@/components/SiteShell';
import { getCopy, localePath, locales } from '@/lib/siteContent';
import { notFound } from 'next/navigation';

export function generateStaticParams() {
  return locales.map((locale) => ({ locale }));
}

export default function HomePage({ params }) {
  const { locale } = params;
  if (!locales.includes(locale)) notFound();

  const copy = getCopy(locale);

  return (
    <SiteShell locale={locale} active="home">
      <section className="homeHeroGrid">
        <PageHero
          eyebrow={copy.home.eyebrow}
          title={copy.home.title}
          text={copy.home.text}
          actions={
            <>
              <Link className="primaryButton" href={localePath(locale, 'apply')}>
                {copy.ctaApply}
              </Link>
              <Link className="secondaryButton" href={localePath(locale, 'performance')}>
                {copy.ctaPerformance}
              </Link>
            </>
          }
        />

        <aside className="commandPanel">
          <div className="panelTop">
            <span>VolatilityForge Command Layer</span>
            <em>Private Room</em>
          </div>
          <div className="heroMetric">
            <span>Model PnL</span>
            <strong>+49.2%</strong>
            <p>Calculated with fixed 0.25% model risk per signal.</p>
          </div>
          <div className="miniMetrics">
            <div><span>Period</span><strong>6 months</strong></div>
            <div><span>Signals</span><strong>232 closed</strong></div>
            <div><span>Direction</span><strong>LONG + SHORT</strong></div>
            <div><span>Format</span><strong>Discord</strong></div>
          </div>
        </aside>
      </section>

      <section className="sectionBlock">
        <div className="sectionHeader">
          <p className="eyebrow">Performance</p>
          <h2>{copy.home.proofTitle}</h2>
          <p>{copy.home.proofText}</p>
        </div>
        <StatGrid stats={copy.performance.stats.slice(0, 3)} />
      </section>

      <section className="sectionBlock splitBlock">
        <article className="panelCard">
          <p className="eyebrow">System</p>
          <h2>{copy.home.systemTitle}</h2>
          <p>{copy.home.systemText}</p>
          <Link className="secondaryButton" href={localePath(locale, 'system')}>{copy.ctaSystem}</Link>
        </article>
        <InfoCards cards={copy.home.cards} />
      </section>
    </SiteShell>
  );
}
