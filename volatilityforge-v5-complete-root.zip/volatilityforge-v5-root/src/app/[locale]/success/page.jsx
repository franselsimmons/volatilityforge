import Link from 'next/link';
import SiteShell, { PageHero } from '@/components/SiteShell';
import { getCopy, localePath, locales } from '@/lib/siteContent';
import { notFound } from 'next/navigation';

export function generateStaticParams() {
  return locales.map((locale) => ({ locale }));
}

export default function SuccessPage({ params }) {
  const { locale } = params;
  if (!locales.includes(locale)) notFound();
  const copy = getCopy(locale);

  return (
    <SiteShell locale={locale} active="success">
      <PageHero
        eyebrow={copy.success.eyebrow}
        title={copy.success.title}
        text={copy.success.text}
        actions={<Link className="secondaryButton" href={localePath(locale)}>{copy.navHome || 'Home'}</Link>}
      />
    </SiteShell>
  );
}
