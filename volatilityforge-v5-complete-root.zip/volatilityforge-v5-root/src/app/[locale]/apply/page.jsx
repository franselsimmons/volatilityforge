import SiteShell, { PageHero } from '@/components/SiteShell';
import { getCopy, locales, plans, t } from '@/lib/siteContent';
import { notFound } from 'next/navigation';

export function generateStaticParams() {
  return locales.map((locale) => ({ locale }));
}

export default function ApplyPage({ params, searchParams }) {
  const { locale } = params;
  if (!locales.includes(locale)) notFound();
  const copy = getCopy(locale);
  const selectedPlan = searchParams?.plan || 'sixMonths';

  return (
    <SiteShell locale={locale} active="apply">
      <PageHero eyebrow={copy.apply.eyebrow} title={copy.apply.title} text={copy.apply.text} />

      <section className="formPanel">
        <form action="/api/apply" method="POST" className="accessForm">
          <input type="hidden" name="locale" value={locale} />

          <label>
            <span>{copy.apply.fields.name}</span>
            <input name="name" required placeholder="Fransel Simmons" />
          </label>

          <label>
            <span>{copy.apply.fields.email}</span>
            <input type="email" name="email" required placeholder="name@email.com" />
          </label>

          <label>
            <span>{copy.apply.fields.experience}</span>
            <select name="experience" defaultValue="intermediate">
              <option value="beginner">Beginner</option>
              <option value="intermediate">Intermediate</option>
              <option value="advanced">Advanced</option>
              <option value="professional">Professional</option>
            </select>
          </label>

          <label>
            <span>{copy.apply.fields.plan}</span>
            <select name="plan" defaultValue={selectedPlan}>
              {plans.map((plan) => (
                <option key={plan.key} value={plan.key}>{t(plan.title, locale)} — {plan.price}</option>
              ))}
            </select>
          </label>

          <label className="fullField">
            <span>{copy.apply.fields.notes}</span>
            <textarea name="notes" rows="5" placeholder="Trading goals, preferred market, questions..." />
          </label>

          <button type="submit" className="primaryButton">{copy.apply.submit}</button>
        </form>
      </section>
    </SiteShell>
  );
}
