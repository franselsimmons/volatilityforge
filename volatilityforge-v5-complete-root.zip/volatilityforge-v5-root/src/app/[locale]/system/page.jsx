import Link from 'next/link';
import SiteShell, { PageHero, StepGrid } from '@/components/SiteShell';
import { getCopy, localePath, locales } from '@/lib/siteContent';
import { notFound } from 'next/navigation';

export function generateStaticParams() {
  return locales.map((locale) => ({ locale }));
}

export default function SystemPage({ params }) {
  const { locale } = params;
  if (!locales.includes(locale)) notFound();
  const copy = getCopy(locale);

  return (
    <SiteShell locale={locale} active="system">
      <PageHero
        eyebrow={copy.system.eyebrow}
        title={copy.system.title}
        text={copy.system.text}
        actions={<Link className="primaryButton" href={localePath(locale, 'signal-room')}>{copy.ctaSignalRoom}</Link>}
      />

      <section className="sectionBlock">
        <StepGrid steps={copy.system.steps} />
      </section>
    </SiteShell>
  );
}
