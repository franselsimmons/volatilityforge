import SiteShell, { PageHero } from '@/components/SiteShell';
import { getCopy, locales } from '@/lib/siteContent';
import { notFound } from 'next/navigation';

export function generateStaticParams() {
  return locales.map((locale) => ({ locale }));
}

export default function RiskDisclaimerPage({ params }) {
  const { locale } = params;
  if (!locales.includes(locale)) notFound();
  const copy = getCopy(locale);

  return (
    <SiteShell locale={locale} active="legal">
      <PageHero eyebrow={copy.legal.eyebrow} title={copy.legal.title} text={copy.legal.text} />

      <section className="legalPanel">
        <h2>Important</h2>
        <p>{copy.riskLine}</p>
        <p>VolatilityForge does not guarantee profit, account growth, win rate or future performance. Any model performance shown on the website must be replaced with clean verified data before launch.</p>
        <p>Users are responsible for their own risk management, execution, leverage, position size and exchange selection.</p>
      </section>
    </SiteShell>
  );
}
