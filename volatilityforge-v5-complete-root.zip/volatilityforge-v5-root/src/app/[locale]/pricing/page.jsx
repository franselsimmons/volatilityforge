import SiteShell, { PageHero } from '@/components/SiteShell';
import PricingCards from '@/components/PricingCards';
import { getCopy, locales } from '@/lib/siteContent';
import { notFound } from 'next/navigation';

export function generateStaticParams() {
  return locales.map((locale) => ({ locale }));
}

export default function PricingPage({ params }) {
  const { locale } = params;
  if (!locales.includes(locale)) notFound();
  const copy = getCopy(locale);

  return (
    <SiteShell locale={locale} active="pricing">
      <PageHero eyebrow={copy.pricing.eyebrow} title={copy.pricing.title} text={copy.pricing.text} />

      <section className="sectionBlock">
        <PricingCards locale={locale} />
        <div className="noticeCard">
          <strong>Stripe-ready</strong>
          <p>{copy.pricing.paymentNote}</p>
        </div>
      </section>

      <section className="sectionBlock">
        <div className="includedPanel">
          <h2>{copy.pricing.includedTitle}</h2>
          <ul>
            {copy.pricing.included.map((item) => <li key={item}>{item}</li>)}
          </ul>
        </div>
      </section>
    </SiteShell>
  );
}
