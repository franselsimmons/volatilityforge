import SiteShell, { PageHero } from '@/components/SiteShell';
import { getCopy, locales } from '@/lib/siteContent';
import { notFound } from 'next/navigation';

export function generateStaticParams() {
  return locales.map((locale) => ({ locale }));
}

export default function FaqPage({ params }) {
  const { locale } = params;
  if (!locales.includes(locale)) notFound();
  const copy = getCopy(locale);

  return (
    <SiteShell locale={locale} active="faq">
      <PageHero eyebrow={copy.faq.eyebrow} title={copy.faq.title} text="" />

      <section className="faqGrid">
        {copy.faq.items.map(([question, answer]) => (
          <article key={question} className="faqCard">
            <h2>{question}</h2>
            <p>{answer}</p>
          </article>
        ))}
      </section>
    </SiteShell>
  );
}
