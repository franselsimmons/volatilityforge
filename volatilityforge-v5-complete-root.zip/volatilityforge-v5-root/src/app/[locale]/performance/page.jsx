import Link from 'next/link';
import SiteShell, { InfoCards, PageHero, StatGrid } from '@/components/SiteShell';
import { getCopy, localePath, locales } from '@/lib/siteContent';
import { notFound } from 'next/navigation';

export function generateStaticParams() {
  return locales.map((locale) => ({ locale }));
}

export default function PerformancePage({ params }) {
  const { locale } = params;
  if (!locales.includes(locale)) notFound();
  const copy = getCopy(locale);

  return (
    <SiteShell locale={locale} active="performance">
      <PageHero
        eyebrow={copy.performance.eyebrow}
        title={copy.performance.title}
        text={copy.performance.text}
        actions={<Link className="primaryButton" href={localePath(locale, 'pricing')}>{copy.ctaPricing}</Link>}
      />

      <section className="sectionBlock">
        <StatGrid stats={copy.performance.stats} />
        <div className="noticeCard">
          <strong>Model notice</strong>
          <p>{copy.performance.note}</p>
        </div>
      </section>

      <section className="sectionBlock">
        <InfoCards cards={copy.performance.explanation} />
      </section>
    </SiteShell>
  );
}
