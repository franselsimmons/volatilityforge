import Link from 'next/link';
import SiteShell, { PageHero, SignalCard } from '@/components/SiteShell';
import { getCopy, localePath, locales } from '@/lib/siteContent';
import { notFound } from 'next/navigation';

export function generateStaticParams() {
  return locales.map((locale) => ({ locale }));
}

export default function SignalRoomPage({ params }) {
  const { locale } = params;
  if (!locales.includes(locale)) notFound();
  const copy = getCopy(locale);

  return (
    <SiteShell locale={locale} active="signal-room">
      <section className="splitBlock">
        <PageHero
          eyebrow={copy.signalRoom.eyebrow}
          title={copy.signalRoom.title}
          text={copy.signalRoom.text}
          actions={<Link className="primaryButton" href={localePath(locale, 'pricing')}>{copy.ctaPricing}</Link>}
        />
        <SignalCard title={copy.signalRoom.exampleTitle} rows={copy.signalRoom.rows} />
      </section>

      <section className="sectionBlock">
        <div className="includedPanel">
          <h2>Included</h2>
          <ul>
            {copy.signalRoom.included.map((item) => <li key={item}>{item}</li>)}
          </ul>
        </div>
      </section>
    </SiteShell>
  );
}
