import Link from 'next/link';
import { getCopy, localePath, locales, routes, t } from '@/lib/siteContent';

export default function SiteShell({ locale, active = 'home', children }) {
  const copy = getCopy(locale);
  const languagePath = active === 'home' ? '' : active === 'legal' ? 'legal/risk-disclaimer' : active;

  return (
    <main className="siteShell">
      <header className="siteHeader">
        <section className="logoBanner" aria-label="VolatilityForge brand banner">
          <Link href={localePath(locale)} className="logoBannerImage" aria-label="VolatilityForge home">
            <img src="/volatilityforge-logo.png" alt="VolatilityForge" />
          </Link>
        </section>

        <div className="topNavigation">
          <Link href={localePath(locale)} className="brandMini" aria-label="VolatilityForge home">
            <span>VolatilityForge</span>
            <small>{copy.brandLine}</small>
          </Link>

          <div className="desktopLanguage">
            {locales.map((item) => (
              <Link key={item} href={localePath(item)} className={item === locale ? 'activeLanguage' : ''}>
                {item.toUpperCase()}
              </Link>
            ))}
          </div>

          <details className="menuDrawer">
            <summary>{copy.menuLabel}</summary>
            <div className="drawerPanel">
              <nav className="drawerLinks" aria-label="Main navigation">
                {routes.map((route) => (
                  <Link key={route.key} href={localePath(locale, route.href)} className={route.key === active ? 'activeRoute' : ''}>
                    {t(route.label, locale)}
                  </Link>
                ))}
              </nav>

              <div className="drawerLanguages">
                <span>{copy.languageLabel}</span>
                <div>
                  {locales.map((item) => (
                    <Link key={item} href={localePath(item, languagePath)} className={item === locale ? 'activeLanguage' : ''}>
                      {item.toUpperCase()}
                    </Link>
                  ))}
                </div>
              </div>
            </div>
          </details>
        </div>
      </header>

      {children}

      <footer className="siteFooter">
        <div>
          <strong>VolatilityForge</strong>
          <p>{copy.brandLine}</p>
        </div>
        <nav>
          <Link href={localePath(locale, 'legal/risk-disclaimer')}>Risk disclaimer</Link>
          <Link href={localePath(locale, 'apply')}>{copy.ctaApply}</Link>
        </nav>
        <small>{copy.riskLine}</small>
      </footer>
    </main>
  );
}

export function PageHero({ eyebrow, title, text, actions }) {
  return (
    <section className="pageHero">
      <p className="eyebrow">{eyebrow}</p>
      <h1>{title}</h1>
      <p>{text}</p>
      {actions ? <div className="heroActions">{actions}</div> : null}
    </section>
  );
}

export function StatGrid({ stats }) {
  return (
    <div className="statGrid">
      {stats.map(([label, value, description]) => (
        <article key={label} className="statCard">
          <span>{label}</span>
          <strong>{value}</strong>
          <p>{description}</p>
        </article>
      ))}
    </div>
  );
}

export function StepGrid({ steps }) {
  return (
    <div className="stepGrid">
      {steps.map(([number, title, text]) => (
        <article key={number} className="stepCard">
          <span>{number}</span>
          <h3>{title}</h3>
          <p>{text}</p>
        </article>
      ))}
    </div>
  );
}

export function SignalCard({ title, rows }) {
  return (
    <article className="signalCard">
      <div className="signalCardHeader">
        <span>Private Discord</span>
        <h2>{title}</h2>
      </div>
      <div className="signalRows">
        {rows.map(([label, value]) => (
          <div key={label}>
            <span>{label}</span>
            <strong>{value}</strong>
          </div>
        ))}
      </div>
    </article>
  );
}

export function InfoCards({ cards }) {
  return (
    <div className="infoGrid">
      {cards.map(([title, text]) => (
        <article key={title} className="infoCard">
          <h3>{title}</h3>
          <p>{text}</p>
        </article>
      ))}
    </div>
  );
}
