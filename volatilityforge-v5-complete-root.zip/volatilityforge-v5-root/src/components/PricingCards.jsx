import Link from 'next/link';
import { plans, t, localePath, getCopy } from '@/lib/siteContent';

function paymentEnabled() {
  return process.env.NEXT_PUBLIC_ENABLE_PAYMENTS === 'true';
}

export default function PricingCards({ locale }) {
  const copy = getCopy(locale);
  const enabled = paymentEnabled();

  return (
    <div className="pricingGrid">
      {plans.map((plan) => (
        <article key={plan.key} className={plan.featured ? 'priceCard featuredPrice' : 'priceCard'}>
          <div className="priceMeta">
            <span>{t(plan.title, locale)}</span>
            <em>{t(plan.tag, locale)}</em>
          </div>
          <div className="priceValue">
            <strong>{plan.price}</strong>
            <small>{t(plan.interval, locale)}</small>
          </div>

          {enabled ? (
            <form action="/api/checkout" method="POST">
              <input type="hidden" name="plan" value={plan.key} />
              <input type="hidden" name="locale" value={locale} />
              <button className={plan.featured ? 'primaryButton fullButton' : 'secondaryButton fullButton'} type="submit">
                {copy.ctaCheckout}
              </button>
            </form>
          ) : (
            <Link className={plan.featured ? 'primaryButton fullButton' : 'secondaryButton fullButton'} href={`${localePath(locale, 'apply')}?plan=${plan.key}`}>
              {copy.ctaWaitlist}
            </Link>
          )}
        </article>
      ))}
    </div>
  );
}
