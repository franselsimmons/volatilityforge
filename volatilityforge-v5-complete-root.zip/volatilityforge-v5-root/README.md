# VolatilityForge V5 Site Root

Complete standalone Next.js site for VolatilityForge.

## Pages

- `/nl`, `/en`, `/de`, `/es`, `/fr`
- `/nl/performance`
- `/nl/system`
- `/nl/signal-room`
- `/nl/pricing`
- `/nl/faq`
- `/nl/apply`
- `/nl/success`
- `/nl/legal/risk-disclaimer`

The same page structure works for all supported locales.

## Logo

The real logo must be here:

```text
public/volatilityforge-logo.png
```

It is already included in this root.

## Payments preparation

Stripe checkout is prepared in:

```text
src/app/api/checkout/route.js
```

Before payments go live, configure these environment variables in Vercel:

```text
NEXT_PUBLIC_SITE_URL
NEXT_PUBLIC_ENABLE_PAYMENTS=true
STRIPE_SECRET_KEY
STRIPE_PRICE_MONTHLY
STRIPE_PRICE_SIX_MONTHS
STRIPE_PRICE_ANNUAL
```

Until `NEXT_PUBLIC_ENABLE_PAYMENTS` is true and Stripe price IDs are filled, pricing buttons route to the access application page.

## Access applications

Application form endpoint:

```text
src/app/api/apply/route.js
```

Optional webhook env:

```text
APPLICATION_WEBHOOK_URL
```

If no webhook is set, the form redirects to the success page without storing data. Connect a webhook before using it live.

## Deploy

```bash
npm install
npm run dev
```

For Vercel: push the complete root to GitHub and import the repository.

## Before live

Do a legal check before taking payments for crypto signals. Replace all model/example performance with your clean real dataset before going public.
